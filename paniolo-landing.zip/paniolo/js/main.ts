/**
 * Paniolo — Main TypeScript
 * Handles: nav scroll state, mobile menu, scroll reveals, form submission
 */

// ── Nav scroll behavior ──────────────────────────────────────────────
const nav = document.querySelector('nav') as HTMLElement | null;

if (nav) {
  const handleScroll = (): void => {
    if (window.scrollY > 20) {
      nav.classList.add('scrolled');
    } else {
      nav.classList.remove('scrolled');
    }
  };
  window.addEventListener('scroll', handleScroll, { passive: true });
  handleScroll(); // run once on load
}

// ── Mobile nav toggle ────────────────────────────────────────────────
const toggle = document.querySelector('.nav-toggle') as HTMLButtonElement | null;
const navLinks = document.querySelector('.nav-links') as HTMLElement | null;

if (toggle && navLinks) {
  toggle.addEventListener('click', () => {
    const isOpen = navLinks.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(isOpen));
    // Animate hamburger bars
    const bars = toggle.querySelectorAll('span');
    if (isOpen) {
      bars[0]?.setAttribute('style', 'transform: rotate(45deg) translate(5px, 5px)');
      bars[1]?.setAttribute('style', 'opacity: 0');
      bars[2]?.setAttribute('style', 'transform: rotate(-45deg) translate(5px, -5px)');
    } else {
      bars.forEach((bar) => bar.removeAttribute('style'));
    }
  });

  // Close on nav link click (mobile)
  navLinks.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', () => {
      navLinks.classList.remove('open');
      toggle.setAttribute('aria-expanded', 'false');
      toggle.querySelectorAll('span').forEach((bar) => bar.removeAttribute('style'));
    });
  });
}

// ── Scroll reveal (IntersectionObserver) ────────────────────────────
const revealElements = document.querySelectorAll<HTMLElement>('.reveal');

const revealObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        // Stagger children slightly
        const delay = (entry.target as HTMLElement).dataset.delay ?? '0';
        setTimeout(() => {
          entry.target.classList.add('visible');
        }, Number(delay));
        revealObserver.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.1, rootMargin: '0px 0px -40px 0px' }
);

revealElements.forEach((el, i) => {
  el.dataset.delay = String(i * 60); // stagger
  revealObserver.observe(el);
});

// ── Counter animation for stats ──────────────────────────────────────
type CounterOptions = {
  el: HTMLElement;
  target: number;
  suffix?: string;
  prefix?: string;
  decimals?: number;
  duration?: number;
};

function animateCounter({
  el,
  target,
  suffix = '',
  prefix = '',
  decimals = 0,
  duration = 1800,
}: CounterOptions): void {
  const start = performance.now();
  const easeOut = (t: number): number => 1 - Math.pow(1 - t, 3);

  const tick = (now: number): void => {
    const elapsed = now - start;
    const progress = Math.min(elapsed / duration, 1);
    const value = target * easeOut(progress);
    el.textContent = `${prefix}${value.toFixed(decimals)}${suffix}`;
    if (progress < 1) requestAnimationFrame(tick);
  };

  requestAnimationFrame(tick);
}

// Trigger counters when stats come into view
const statNumbers = document.querySelectorAll<HTMLElement>('[data-count]');

const counterObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        const el = entry.target as HTMLElement;
        const target = parseFloat(el.dataset.count ?? '0');
        const suffix = el.dataset.suffix ?? '';
        const prefix = el.dataset.prefix ?? '';
        const decimals = parseInt(el.dataset.decimals ?? '0', 10);
        animateCounter({ el, target, suffix, prefix, decimals });
        counterObserver.unobserve(el);
      }
    });
  },
  { threshold: 0.5 }
);

statNumbers.forEach((el) => counterObserver.observe(el));

// ── Contact form ──────────────────────────────────────────────────────
const form = document.querySelector<HTMLFormElement>('#contact-form');
const formSuccess = document.querySelector<HTMLElement>('#form-success');

if (form) {
  form.addEventListener('submit', (e: Event) => {
    e.preventDefault();
    const submitBtn = form.querySelector<HTMLButtonElement>('[type="submit"]');

    if (submitBtn) {
      submitBtn.textContent = 'Sending…';
      submitBtn.setAttribute('disabled', 'true');
    }

    // Simulate async submission — replace with real endpoint
    setTimeout(() => {
      form.style.display = 'none';
      if (formSuccess) formSuccess.style.display = 'block';
    }, 900);
  });
}

// ── Smooth anchor scrolling ───────────────────────────────────────────
document.querySelectorAll<HTMLAnchorElement>('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener('click', (e: Event) => {
    const href = anchor.getAttribute('href');
    if (!href || href === '#') return;
    const target = document.querySelector<HTMLElement>(href);
    if (target) {
      e.preventDefault();
      const offset = (nav?.offsetHeight ?? 72) + 16;
      const top = target.getBoundingClientRect().top + window.scrollY - offset;
      window.scrollTo({ top, behavior: 'smooth' });
    }
  });
});
